package umn.ac.assignment01_36266;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText display;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.input);
        display.setShowSoftInputOnFocus(false);

        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(getString(R.string.display).equals(display.getText().toString())){
                    display.setText("");
                }
            }
        });
    }

    public void zeroBTN(View view){

    }

    public void oneBTN(View view){

    }

    public void twoBTN(View view){

    }

    public void threeBTN(View view){

    }

    public void fourBTN(View view){

    }

    public void fiveBTN(View view){

    }

    public void sixBTN(View view){

    }

    public void sevenBTN(View view){

    }

    public void eightBTN(View view){

    }

    public void nineBTN(View view){

    }

    public void equalsBTN(View view){

    }

    public void plusminusBTN(View view){

    }

    public void clearBTN(View view){

    }

    public void clearEntryBTN(View view){

    }

    public void backBTN(View view){

    }

    public void plusBTN(View view){

    }

    public void minusBTN(View view){

    }

    public void multiplyBTN(View view){

    }

    public void divideBTN(View view){

    }

    public void komaBTN(View view){

    }
}